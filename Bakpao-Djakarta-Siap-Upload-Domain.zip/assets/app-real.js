(()=>{'use strict';
const $=(s,r=document)=>r.querySelector(s), $$=(s,r=document)=>[...r.querySelectorAll(s)];
const data=JSON.parse($('#catalog-data')?.textContent||'{"menu":[],"photos":[],"outlets":[]}');
const menu=data.menu,photos=data.photos,outlets=data.outlets;
const safe=s=>String(s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const format=n=>'Rp'+new Intl.NumberFormat('id-ID').format(n);
const photoImg=(src,alt,cls='')=>`<img class="${cls}" src="${safe(src)}?v=custom-20261029" alt="${safe(alt)}">`;
let favorites=[];try{favorites=JSON.parse(localStorage.getItem('bakpau-favorites')||'[]');if(!Array.isArray(favorites))favorites=[]}catch{}
let activeFilter='all',searchValue='',sortValue='default',toastTimer,activePhoto=null;
function toast(message){const el=$('.toast');el.textContent=message;el.classList.add('show');clearTimeout(toastTimer);toastTimer=setTimeout(()=>el.classList.remove('show'),2400)}
function syncFavorites(){$$('[data-favorite]').forEach(b=>{const on=favorites.includes(b.dataset.favorite);b.setAttribute('aria-pressed',String(on));b.textContent=on?'♥':'♡';b.setAttribute('aria-label',on?'Hapus dari favorit':'Simpan ke favorit')})}
function toggleFavorite(id){const on=favorites.includes(id);favorites=on?favorites.filter(x=>x!==id):[...favorites,id];try{localStorage.setItem('bakpau-favorites',JSON.stringify(favorites))}catch{}syncFavorites();if(activeFilter==='favorites')filterMenu();const b=$('.favorite-detail');if(b&&b.dataset.id===id)b.textContent=favorites.includes(id)?'♥ Tersimpan di favorit':'♡ Simpan ke favorit';toast(on?'Dihapus dari favorit':'Tersimpan! Pilihan lezatmu ada di favorit ♡')}
const navButton=$('.nav-toggle'),nav=$('#nav');
function closeNav(){nav?.classList.remove('open');navButton?.setAttribute('aria-expanded','false');navButton?.setAttribute('aria-label','Buka menu navigasi')}
navButton?.addEventListener('click',()=>{const open=navButton.getAttribute('aria-expanded')!=='true';nav.classList.toggle('open',open);navButton.setAttribute('aria-expanded',String(open));navButton.setAttribute('aria-label',open?'Tutup menu navigasi':'Buka menu navigasi')});
document.addEventListener('click',e=>{if(!e.target.closest('header'))closeNav()});
$('#back-top')?.addEventListener('click',()=>window.scrollTo({top:0,behavior:matchMedia('(prefers-reduced-motion: reduce)').matches?'instant':'smooth'}));
const dialog=$('#product-dialog');
dialog?.querySelector('.dialog-close')?.addEventListener('click',()=>dialog.close());
dialog?.addEventListener('close',()=>{activePhoto=null;dialog.classList.remove('photo-lightbox')});
dialog?.addEventListener('click',e=>{if(e.target===dialog){const r=dialog.getBoundingClientRect();if(e.clientX<r.left||e.clientX>r.right||e.clientY<r.top||e.clientY>r.bottom)dialog.close()}});
function openProduct(id){const x=menu.find(p=>p.id===id);if(!x)return;activePhoto=null;dialog.classList.remove('photo-lightbox');
const cut=(key,alt)=>key==='mini'?'<span class="mini-no-tray" role="img" aria-label="Foto bakpao Mini tanpa alas"></span>':photoImg('assets/cutouts/'+key+'.png',alt,'menu-cutout');
const content=x.cutouts?`<div class="cutout-assortment items-${x.cutouts.length}">${x.cutouts.map(k=>cut(k,'Pilihan bakpao '+k)).join('')}</div>`:x.cutout==='mini-crop'?cut('mini',x.name):photoImg(x.cutout,x.photo_alt||x.name,'menu-cutout');
const visual=`<div class="dialog-art dialog-cutout ${safe(x.color)}"><div class="menu-circle ${x.cutouts?'package-circle':''}">${content}</div></div>`;
const orderURL='https://wa.me/62816606986?text='+encodeURIComponent('Halo Bakpao Djakarta, saya ingin memesan '+x.name+' (harga menu '+format(x.price)+'). Mohon info ketersediaannya.');
$('#dialog-body').innerHTML=`<div class="dialog-layout">${visual}<div class="dialog-copy"><span class="eyebrow">${x.category==='paket'?'PAKET BERBAGI':'PILIHAN '+safe(x.category.toUpperCase())}</span><h2 id="dialog-title">${safe(x.name)}</h2><p>${safe(x.desc)}</p><strong>${format(x.price)}</strong><a class="button primary" href="${orderURL}" target="_blank" rel="noopener noreferrer">Pesan via WhatsApp <span>↗</span></a><button class="favorite-detail" data-id="${safe(x.id)}">${favorites.includes(x.id)?'♥ Tersimpan di favorit':'♡ Simpan ke favorit'}</button><p class="dialog-note">Tanyakan ketersediaan menu dan kebutuhan pesanan melalui WhatsApp +62 816-606-986. Kamu juga dapat membeli langsung di outlet.</p><div class="dialog-store-links">${outlets.map(o=>`<a href="${safe(o.maps)}" target="_blank" rel="noopener noreferrer">${safe(o.name)} ↗</a>`).join('')}</div></div></div>`;
$('.favorite-detail',dialog).addEventListener('click',()=>toggleFavorite(x.id));if(!dialog.open)dialog.showModal();
}
function openPhoto(index){if(!photos.length)return;activePhoto=(Number(index)+photos.length)%photos.length;const p=photos[activePhoto];dialog.classList.add('photo-lightbox');$('#dialog-body').innerHTML=`<div class="lightbox-top"><h2 id="dialog-title">${safe(p.title||("Bakpao "+p.name))}</h2><span class="lightbox-counter">${activePhoto+1} / ${photos.length}</span></div>${photoImg(p.src,p.alt,'lightbox-image')}<div class="lightbox-navigation"><button class="photo-prev" aria-label="Foto sebelumnya">‹</button><p>Foto produk asli Bakpao Djakarta</p><button class="photo-next" aria-label="Foto berikutnya">›</button></div>`;$('.photo-prev',dialog).addEventListener('click',()=>openPhoto(activePhoto-1));$('.photo-next',dialog).addEventListener('click',()=>openPhoto(activePhoto+1));if(!dialog.open)dialog.showModal()}
document.addEventListener('keydown',e=>{if(e.key==='Escape')closeNav();if(dialog?.open&&activePhoto!==null){if(e.key==='ArrowLeft'){e.preventDefault();openPhoto(activePhoto-1)}if(e.key==='ArrowRight'){e.preventDefault();openPhoto(activePhoto+1)}}});
document.addEventListener('click',e=>{const f=e.target.closest('[data-favorite]');if(f){toggleFavorite(f.dataset.favorite);return}const p=e.target.closest('[data-product]');if(p){openProduct(p.dataset.product);return}const photo=e.target.closest('[data-photo]');if(photo)openPhoto(photo.dataset.photo)});
function filterMenu(){const grid=$('#menu-grid');if(!grid)return;const query=searchValue.trim().toLocaleLowerCase('id-ID');let matches=menu.filter(x=>(activeFilter==='all'||(activeFilter==='favorites'?favorites.includes(x.id):x.category===activeFilter))&&`${x.name} ${x.full} ${x.flavor} ${x.desc} ${x.character||''}`.toLocaleLowerCase('id-ID').includes(query));if(sortValue==='low')matches.sort((a,b)=>a.price-b.price);if(sortValue==='high')matches.sort((a,b)=>b.price-a.price);if(sortValue==='name')matches.sort((a,b)=>a.name.localeCompare(b.name,'id'));const ids=new Set(matches.map(x=>x.id));$$('.product-card',grid).forEach(c=>c.hidden=!ids.has(c.dataset.id));matches.forEach(x=>{const c=grid.querySelector(`[data-id="${x.id}"]`);if(c)grid.append(c)});$('#menu-empty').hidden=matches.length>0;$('#result-count').textContent=matches.length+' pilihan untukmu'}
$$('[data-filter]').forEach(b=>b.addEventListener('click',()=>{activeFilter=b.dataset.filter;$$('[data-filter]').forEach(x=>{const on=x===b;x.classList.toggle('active',on);x.setAttribute('aria-pressed',String(on))});filterMenu()}));
$('#menu-search')?.addEventListener('input',e=>{searchValue=e.target.value;filterMenu()});$('#sort')?.addEventListener('change',e=>{sortValue=e.target.value;filterMenu()});
$('#reset-filters')?.addEventListener('click',()=>{activeFilter='all';searchValue='';sortValue='default';$('#menu-search').value='';$('#sort').value='default';$$('[data-filter]').forEach(x=>{const on=x.dataset.filter==='all';x.classList.toggle('active',on);x.setAttribute('aria-pressed',String(on))});filterMenu()});
const q=new URLSearchParams(location.search).get('q');if(q&&$('#menu-search')){$('#menu-search').value=q;searchValue=q}syncFavorites();filterMenu();
const strip=$('.real-strip'),pause=$('.photo-pause');let paused=false;
pause?.addEventListener('click',()=>{paused=!paused;strip.classList.toggle('is-paused',paused);pause.setAttribute('aria-pressed',String(paused));pause.setAttribute('aria-label',paused?'Lanjutkan galeri bergerak':'Jeda galeri bergerak');$('.pause-icon',pause).textContent=paused?'▷':'Ⅱ';$('.pause-label',pause).textContent=paused?'Lanjutkan galeri':'Jeda galeri'});
$$('.real-photo-card').forEach(b=>b.addEventListener('focus',()=>{if(b.matches(':focus-visible'))requestAnimationFrame(()=>b.scrollIntoView({block:'nearest',inline:'nearest'}))}));
const customForm=$('#custom-form');
if(customForm){
 const date=customForm.elements.event_date,now=new Date();date.min=now.getFullYear()+'-'+String(now.getMonth()+1).padStart(2,'0')+'-'+String(now.getDate()).padStart(2,'0');
 customForm.addEventListener('submit',e=>{e.preventDefault();if(!customForm.reportValidity())return;
 const fields=new FormData(customForm);const who=String(fields.get('customer')||'').trim(),day=String(fields.get('event_date'));const shownDate=new Date(day+'T12:00:00').toLocaleDateString('id-ID',{day:'numeric',month:'long',year:'numeric'});
 const message='Halo Bakpao Djakarta, saya ingin konsultasi pesanan custom.'+(who?'\nNama: '+who:'')+'\nMomen: '+fields.get('occasion')+'\nTanggal acara: '+shownDate+'\nPerkiraan jumlah: '+fields.get('quantity')+' pcs\nTema / ide: '+String(fields.get('theme')).trim()+'\nMohon info desain, pilihan rasa, harga, jumlah minimum, dan waktu persiapannya. Terima kasih.';
 let result=$('#custom-summary');if(!result){result=document.createElement('div');result.id='custom-summary';result.className='custom-summary';result.setAttribute('role','status');customForm.append(result)}
 result.innerHTML='<h4>Pesan konsultasimu siap</h4><p class="custom-message-preview"></p><a class="button dark" target="_blank" rel="noopener noreferrer">Lanjutkan ke WhatsApp ↗</a>';
 $('.custom-message-preview',result).textContent=message;$('a',result).href='https://wa.me/62816606986?text='+encodeURIComponent(message);result.scrollIntoView({behavior:matchMedia('(prefers-reduced-motion: reduce)').matches?'instant':'smooth',block:'nearest'});
 });
 customForm.addEventListener('input',()=>$('#custom-summary')?.remove());
}
})();
