(()=>{'use strict';
const motion=matchMedia('(prefers-reduced-motion: reduce)');
const hero=document.querySelector('.reactive-hero');
if(hero){
 const fine=matchMedia('(pointer: fine)');
 hero.addEventListener('pointermove',e=>{if(motion.matches||!fine.matches)return;const r=hero.getBoundingClientRect();hero.style.setProperty('--look-x',(((e.clientX-r.left)/r.width-.5)*12).toFixed(2)+'px');hero.style.setProperty('--look-y',(((e.clientY-r.top)/r.height-.5)*9).toFixed(2)+'px')});
 hero.addEventListener('pointerleave',()=>{hero.style.setProperty('--look-x','0px');hero.style.setProperty('--look-y','0px')});
 const timers=new WeakMap();let statusTimer;
 hero.querySelectorAll('.boop').forEach(b=>b.addEventListener('click',()=>{clearTimeout(timers.get(b));clearTimeout(statusTimer);b.classList.remove('is-celebrating');const speech=b.querySelector('.hero-bao-speech');speech.textContent=b.dataset.greet;requestAnimationFrame(()=>b.classList.add('is-celebrating'));hero.querySelector('.hero-greeting').textContent=b.dataset.character+': '+b.dataset.greet;timers.set(b,setTimeout(()=>b.classList.remove('is-celebrating'),1800));statusTimer=setTimeout(()=>hero.querySelector('.hero-greeting').textContent='',4200)}));
}
const parade=document.querySelector('.reactive-parade');
if(parade){
 const pause=parade.querySelector('.parade-pause');let paused=motion.matches,interactionTimer;
 const syncPause=()=>{parade.classList.toggle('is-paused',paused);pause.hidden=motion.matches;pause.setAttribute('aria-pressed',String(paused));pause.setAttribute('aria-label',paused?'Lanjutkan animasi bakpao berjalan':'Jeda animasi bakpao berjalan');pause.querySelector('.pause-icon').textContent=paused?'▷':'Ⅱ';pause.querySelector('.pause-label').textContent=paused?'Lanjutkan animasi':'Jeda animasi'};
 pause.addEventListener('click',()=>{paused=!paused;syncPause()});
 const timers=new WeakMap();
 parade.querySelectorAll('.walking-bun').forEach(b=>{
  const cheer=()=>{clearTimeout(timers.get(b));clearTimeout(interactionTimer);b.classList.remove('is-cheering');b.querySelector('.walking-speech').textContent=b.dataset.greet;requestAnimationFrame(()=>b.classList.add('is-cheering'));parade.classList.add('is-interacting');parade.querySelector('.parade-announcement').textContent=b.dataset.character+': '+b.dataset.greet;timers.set(b,setTimeout(()=>b.classList.remove('is-cheering'),2100));interactionTimer=setTimeout(()=>parade.classList.remove('is-interacting'),2300)};
  b.addEventListener('click',cheer);b.addEventListener('pointerenter',e=>{if(e.pointerType!=='touch')cheer()});b.addEventListener('focus',()=>{if(b.matches(':focus-visible'))requestAnimationFrame(()=>b.scrollIntoView({block:'nearest',inline:'nearest'}))});
 });
 motion.addEventListener('change',()=>{paused=motion.matches;syncPause()});syncPause();
}
})();
